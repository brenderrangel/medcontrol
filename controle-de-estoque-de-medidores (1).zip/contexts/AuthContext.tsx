import React, { createContext, useContext, useState, ReactNode, useCallback } from 'react';
import { User, UserRole } from '../types';
import { INITIAL_USERS, WAREHOUSES } from '../constants';
import useLocalStorage from '../hooks/useLocalStorage';

interface AuthContextType {
  currentUser: User | null;
  users: User[];
  login: (email: string, password?: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
  addUser: (userData: Omit<User, 'id' | 'assignedWarehouseIds'> & { password?: string; assignedWarehouseIds?: string[] }) => { success: boolean; message: string };
  updateUser: (updatedUserData: User & { password?: string }) => { success: boolean; message: string };
  deleteUser: (userId: string) => { success: boolean; message: string };
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const generateId = () => `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [users, setUsers] = useLocalStorage<User[]>('appUsers', INITIAL_USERS);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const login = useCallback(async (email: string, password?: string): Promise<boolean> => {
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (user && (user.password === password || (!user.password && !password))) {
      setCurrentUser(user);
      return true;
    }
    setCurrentUser(null);
    return false;
  }, [users]);

  const logout = useCallback(() => {
    setCurrentUser(null);
  }, []);

  const isAuthenticated = !!currentUser;

  const addUser = (userData: Omit<User, 'id' | 'assignedWarehouseIds'> & { password?: string; assignedWarehouseIds?: string[] }): { success: boolean; message: string } => {
    if (!userData.password) {
      return { success: false, message: 'Senha é obrigatória para novos usuários.' };
    }
    const existingUser = users.find(u => u.email.toLowerCase() === userData.email.toLowerCase());
    if (existingUser) {
      return { success: false, message: 'Email já cadastrado.' };
    }
    
    const assignedWarehouseIds = userData.role === 'admin' 
      ? WAREHOUSES.map(wh => wh.id) 
      : userData.assignedWarehouseIds || [];

    if (userData.role === 'user' && assignedWarehouseIds.length === 0) {
        return { success: false, message: 'Usuários devem ter ao menos um almoxarifado atribuído.'};
    }

    const newUser: User = { 
      ...userData, 
      id: generateId(),
      password: userData.password, // Explicitly include password
      assignedWarehouseIds 
    };
    setUsers(prevUsers => [...prevUsers, newUser]);
    return { success: true, message: 'Usuário adicionado com sucesso.' };
  };

  const updateUser = (updatedUserData: User & { password?: string }): { success: boolean; message: string } => {
    const existingUserByEmail = users.find(u => u.email.toLowerCase() === updatedUserData.email.toLowerCase() && u.id !== updatedUserData.id);
    if (existingUserByEmail) {
      return { success: false, message: 'Email já cadastrado por outro usuário.' };
    }

    const assignedWarehouseIds = updatedUserData.role === 'admin'
        ? WAREHOUSES.map(wh => wh.id)
        : updatedUserData.assignedWarehouseIds || [];
    
    if (updatedUserData.role === 'user' && assignedWarehouseIds.length === 0) {
        return { success: false, message: 'Usuários devem ter ao menos um almoxarifado atribuído.'};
    }

    setUsers(prevUsers => prevUsers.map(u => {
      if (u.id === updatedUserData.id) {
        const userWithPotentiallyNewPassword = { ...u, ...updatedUserData, assignedWarehouseIds };
        // Only update password if a new one is provided and it's not an empty string
        if (updatedUserData.password && updatedUserData.password.trim() !== '') {
          userWithPotentiallyNewPassword.password = updatedUserData.password;
        } else {
          // If password field was intentionally blanked or not provided, keep old password
          userWithPotentiallyNewPassword.password = u.password; 
        }
        return userWithPotentiallyNewPassword;
      }
      return u;
    }));

    if (currentUser && currentUser.id === updatedUserData.id) {
      // Refetch the updated user from the users array to ensure currentUser state is correct
       const updatedCurrentUser = users.find(u => u.id === updatedUserData.id);
        if (updatedCurrentUser) {
            // If password was changed for current user, it's not directly reflected here
            // but the rest of the data is. This is fine for display purposes.
            // For a true reflection, one might re-fetch from `users` list AFTER setUsers.
             setCurrentUser(prev => ({
                ...prev!, // prev is known to be non-null here
                ...updatedUserData,
                assignedWarehouseIds, // ensure this is updated too
                // Password is not directly stored in currentUser in a way that reflects changes immediately if edited by self
                // It's safer to keep current user object's password as is, or re-login conceptually.
                // For now, update other fields.
             }));
        }
    }
    return { success: true, message: 'Usuário atualizado com sucesso.' };
  };

  const deleteUser = (userId: string): { success: boolean; message: string } => {
    if (currentUser && currentUser.id === userId) {
      return { success: false, message: 'Você não pode excluir sua própria conta.' };
    }
    const userToDelete = users.find(u => u.id === userId);
    if (!userToDelete) {
      return { success: false, message: 'Usuário não encontrado.' };
    }
    if (userToDelete.role === 'admin') {
      const adminUsers = users.filter(u => u.role === 'admin');
      if (adminUsers.length <= 1) {
        return { success: false, message: 'Não é possível excluir o último administrador do sistema.' };
      }
    }
    setUsers(prevUsers => prevUsers.filter(u => u.id !== userId));
    return { success: true, message: 'Usuário excluído com sucesso.' };
  };

  return (
    <AuthContext.Provider value={{ currentUser, users, login, logout, isAuthenticated, addUser, updateUser, deleteUser, setUsers }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
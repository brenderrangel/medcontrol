
import React, { createContext, useContext, useState, ReactNode, useCallback, useMemo } from 'react';
import { InventoryTransaction, MeterType, WarehouseInfo, CurrentStock, TransactionType } from '../types';
import { INITIAL_METER_TYPES, WAREHOUSES } from '../constants';
import useLocalStorage from '../hooks/useLocalStorage';

interface InventoryContextType {
  meterTypes: MeterType[];
  warehouses: WarehouseInfo[];
  transactions: InventoryTransaction[];
  addTransaction: (transaction: Omit<InventoryTransaction, 'id' | 'timestamp'>) => void;
  currentStock: CurrentStock[];
  deleteTransaction: (transactionId: string) => void;
  addMeterType: (meterTypeData: Omit<MeterType, 'id' | 'saldoEmergencia' | 'saldoNL' | 'lteLigTemp' | 'reaproveitados'>) => { success: boolean; message: string };
  updateMeterType: (updatedMeterTypeData: MeterType) => { success: boolean; message: string };
}

const InventoryContext = createContext<InventoryContextType | undefined>(undefined);

// Simple ID generator
const generateId = () => `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;

export const InventoryProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [meterTypes, setMeterTypes] = useLocalStorage<MeterType[]>('meterTypes', INITIAL_METER_TYPES);
  const [warehouses] = useState<WarehouseInfo[]>(WAREHOUSES);
  const [transactions, setTransactions] = useLocalStorage<InventoryTransaction[]>('inventoryTransactions', []);

  const addTransaction = useCallback((transactionData: Omit<InventoryTransaction, 'id' | 'timestamp'>) => {
    const newTransaction: InventoryTransaction = {
      ...transactionData,
      id: generateId(),
      timestamp: new Date().toISOString(),
    };
    setTransactions(prevTransactions => [...prevTransactions, newTransaction]);
  }, [setTransactions]);
  
  const deleteTransaction = useCallback((transactionId: string) => {
    setTransactions(prevTransactions => prevTransactions.filter(t => t.id !== transactionId));
  }, [setTransactions]);

  const addMeterType = useCallback((meterTypeData: Omit<MeterType, 'id' | 'saldoEmergencia' | 'saldoNL' | 'lteLigTemp' | 'reaproveitados'>): { success: boolean; message: string } => {
    const existingMeterTypeByCodE4E = meterTypes.find(mt => mt.codE4E === meterTypeData.codE4E);
    if (existingMeterTypeByCodE4E) {
      return { success: false, message: `Já existe um tipo de medidor com o Código E4E: ${meterTypeData.codE4E}` };
    }
    const newMeterType: MeterType = {
      ...meterTypeData,
      id: meterTypeData.codE4E, // Use codE4E as the ID for new entries
    };
    setMeterTypes(prevMeterTypes => [...prevMeterTypes, newMeterType]);
    return { success: true, message: 'Tipo de medidor adicionado com sucesso!' };
  }, [meterTypes, setMeterTypes]);

  const updateMeterType = useCallback((updatedMeterTypeData: MeterType): { success: boolean; message: string } => {
    // Check if the updated codE4E conflicts with another meter type (excluding itself)
    const conflictingMeterType = meterTypes.find(
      mt => mt.codE4E === updatedMeterTypeData.codE4E && mt.id !== updatedMeterTypeData.id
    );
    if (conflictingMeterType) {
      return { success: false, message: `O Código E4E '${updatedMeterTypeData.codE4E}' já está em uso por outro tipo de medidor.` };
    }

    setMeterTypes(prevMeterTypes =>
      prevMeterTypes.map(mt =>
        mt.id === updatedMeterTypeData.id ? { ...mt, ...updatedMeterTypeData } : mt
      )
    );
    return { success: true, message: 'Tipo de medidor atualizado com sucesso!' };
  }, [meterTypes, setMeterTypes]);


  const currentStock = useMemo(() => {
    const stockMap = new Map<string, CurrentStock>();

    warehouses.forEach(wh => {
      meterTypes.forEach(mt => {
        const key = `${mt.id}-${wh.id}`;
        stockMap.set(key, {
          meterTypeId: mt.id,
          meterTypeDesc: mt.descricao,
          warehouseId: wh.id,
          warehouseName: wh.name,
          quantity: 0,
        });
      });
    });

    transactions.forEach(t => {
      const key = `${t.meterTypeId}-${t.warehouseId}`;
      const stockItem = stockMap.get(key);
      if (stockItem) {
        if (t.transactionType === TransactionType.IN) {
          stockItem.quantity += t.quantity;
        } else if (t.transactionType === TransactionType.OUT) {
          stockItem.quantity -= t.quantity;
        } else if (t.transactionType === TransactionType.ADJUSTMENT) {
            stockItem.quantity += t.quantity; 
        }
      }
    });
    return Array.from(stockMap.values());
  }, [transactions, meterTypes, warehouses]);


  return (
    <InventoryContext.Provider value={{ meterTypes, warehouses, transactions, addTransaction, currentStock, deleteTransaction, addMeterType, updateMeterType }}>
      {children}
    </InventoryContext.Provider>
  );
};

export const useInventory = (): InventoryContextType => {
  const context = useContext(InventoryContext);
  if (!context) {
    throw new Error('useInventory must be used within an InventoryProvider');
  }
  return context;
};

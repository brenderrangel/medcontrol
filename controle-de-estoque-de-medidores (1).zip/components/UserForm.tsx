import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useInventory } from '../contexts/InventoryContext';
import { User, UserRole, WarehouseInfo } from '../types';

interface UserFormProps {
  userToEdit?: User | null;
  onSuccess: () => void;
  onCancel: () => void;
}

const UserForm: React.FC<UserFormProps> = ({ userToEdit, onSuccess, onCancel }) => {
  const { addUser, updateUser, currentUser } = useAuth();
  const { warehouses } = useInventory(); // Get warehouses for selection

  const initialFormState = {
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'user' as UserRole,
    assignedWarehouseIds: [] as string[],
  };

  const [formData, setFormData] = useState(initialFormState);
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  useEffect(() => {
    if (userToEdit) {
      setFormData({
        name: userToEdit.name,
        email: userToEdit.email,
        password: '', // Keep password blank for editing, user can fill if they want to change
        confirmPassword: '',
        role: userToEdit.role,
        assignedWarehouseIds: userToEdit.assignedWarehouseIds || [],
      });
      setFeedbackMessage(null);
    } else {
      setFormData(initialFormState);
    }
  }, [userToEdit]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleWarehouseChange = (warehouseId: string) => {
    setFormData(prev => {
      const newAssignedWarehouseIds = prev.assignedWarehouseIds.includes(warehouseId)
        ? prev.assignedWarehouseIds.filter(id => id !== warehouseId)
        : [...prev.assignedWarehouseIds, warehouseId];
      return { ...prev, assignedWarehouseIds: newAssignedWarehouseIds };
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedbackMessage(null);

    if (!formData.name || !formData.email) {
      setFeedbackMessage({ type: 'error', message: 'Nome e Email são obrigatórios.' });
      return;
    }
    if (formData.password !== formData.confirmPassword) {
      setFeedbackMessage({ type: 'error', message: 'As senhas não coincidem.' });
      return;
    }
    if (!userToEdit && !formData.password) { // Password required for new users
      setFeedbackMessage({ type: 'error', message: 'Senha é obrigatória para novos usuários.' });
      return;
    }
    if (formData.role === 'user' && formData.assignedWarehouseIds.length === 0) {
        setFeedbackMessage({ type: 'error', message: 'Usuários devem ter ao menos um almoxarifado atribuído.' });
        return;
    }


    let result;
    const dataToSubmit: any = {
      name: formData.name,
      email: formData.email,
      role: formData.role,
      assignedWarehouseIds: formData.role === 'admin' ? warehouses.map(wh => wh.id) : formData.assignedWarehouseIds,
    };
    
    if (formData.password) { // Only include password if it's been entered
      dataToSubmit.password = formData.password;
    }

    if (userToEdit) {
      result = updateUser({ ...userToEdit, ...dataToSubmit });
    } else {
      result = addUser(dataToSubmit);
    }

    setFeedbackMessage({ type: result.success ? 'success' : 'error', message: result.message });

    if (result.success) {
      setTimeout(() => {
        setFeedbackMessage(null);
        onSuccess();
      }, 1500);
      if (!userToEdit) {
        setFormData(initialFormState);
      }
    }
  };

  const commonInputClass = "mt-1 block w-full p-2.5 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-gray-50 text-slate-800";
  const commonLabelClass = "block text-sm font-medium text-gray-700 mb-1";
  const formTitle = userToEdit ? "Editar Usuário" : "Adicionar Novo Usuário";
  const submitButtonText = userToEdit ? "Salvar Alterações" : "Adicionar Usuário";
  
  // Prevent editing role of current admin user by themselves to avoid lockout, or if it's the only admin
  const isRoleEditingDisabled = userToEdit && userToEdit.id === currentUser?.id && userToEdit.role === 'admin';


  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow-lg space-y-6 border border-blue-200">
      <h3 className="text-xl font-semibold text-gray-700">{formTitle}</h3>

      {feedbackMessage && (
        <div className={`p-3 rounded-md text-sm ${feedbackMessage.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`} role="alert">
          {feedbackMessage.message}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="name" className={commonLabelClass}>Nome Completo</label>
          <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} className={commonInputClass} required aria-required="true" />
        </div>
        <div>
          <label htmlFor="email" className={commonLabelClass}>Email</label>
          <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} className={commonInputClass} required aria-required="true" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="password" className={commonLabelClass}>
            Senha {userToEdit ? <span className="text-xs text-gray-500">(deixe em branco para não alterar)</span> : ''}
          </label>
          <input type="password" id="password" name="password" value={formData.password} onChange={handleChange} className={commonInputClass} aria-required={!userToEdit} />
        </div>
        <div>
          <label htmlFor="confirmPassword" className={commonLabelClass}>Confirmar Senha</label>
          <input type="password" id="confirmPassword" name="confirmPassword" value={formData.confirmPassword} onChange={handleChange} className={commonInputClass} aria-required={!userToEdit && !!formData.password} />
        </div>
      </div>
      
      <div>
        <label htmlFor="role" className={commonLabelClass}>Perfil</label>
        <select id="role" name="role" value={formData.role} onChange={handleChange} className={commonInputClass} required aria-required="true" disabled={isRoleEditingDisabled}>
          <option value="user">Usuário (User)</option>
          <option value="admin">Administrador (Admin)</option>
        </select>
        {isRoleEditingDisabled && <p className="text-xs text-gray-500 mt-1">Não é possível alterar o perfil do administrador atual.</p>}
      </div>

      {formData.role === 'user' && (
        <div>
          <label className={commonLabelClass}>Almoxarifados Atribuídos</label>
          <div className="mt-2 space-y-2 p-3 border border-gray-300 rounded-lg max-h-48 overflow-y-auto bg-gray-50">
            {warehouses.length > 0 ? warehouses.map((wh: WarehouseInfo) => (
              <div key={wh.id} className="flex items-center">
                <input
                  type="checkbox"
                  id={`warehouse-${wh.id}`}
                  name="assignedWarehouseIds"
                  value={wh.id}
                  checked={formData.assignedWarehouseIds.includes(wh.id)}
                  onChange={() => handleWarehouseChange(wh.id)}
                  className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                />
                <label htmlFor={`warehouse-${wh.id}`} className="ml-2 text-sm text-gray-700">{wh.name}</label>
              </div>
            )) : <p className="text-sm text-gray-500">Nenhum almoxarifado cadastrado.</p>}
          </div>
           {formData.assignedWarehouseIds.length === 0 && <p className="text-xs text-red-500 mt-1">Selecione ao menos um almoxarifado para usuários.</p>}
        </div>
      )}
       {formData.role === 'admin' && (
         <p className="text-sm text-gray-600 bg-blue-50 p-3 rounded-md border border-blue-200">
            Administradores têm acesso a todos os almoxarifados automaticamente.
        </p>
      )}


      <div className="flex justify-end space-x-3 pt-4">
        <button
          type="button"
          onClick={onCancel}
          className="py-2 px-4 bg-gray-200 hover:bg-gray-300 text-gray-700 font-semibold rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400 transition-colors"
        >
          Cancelar
        </button>
        <button
          type="submit"
          className="py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
        >
          {submitButtonText}
        </button>
      </div>
    </form>
  );
};

export default UserForm;

import React, { useState, useEffect } from 'react';
import { useInventory } from '../contexts/InventoryContext';
import { TransactionType, WarehouseInfo, MeterType } from '../types';

interface DataEntryFormProps {
  initialData?: {
    warehouseId?: string;
    meterTypeId?: string;
    currentQuantity?: number;
    transactionType?: TransactionType;
  } | null;
}

const SuccessIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
    <polyline points="22 4 12 14.01 9 11.01"></polyline>
  </svg>
);

const ErrorIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10"></circle>
    <line x1="12" y1="8" x2="12" y2="12"></line>
    <line x1="12" y1="16" x2="12.01" y2="16"></line>
  </svg>
);


const DataEntryForm: React.FC<DataEntryFormProps> = ({ initialData }) => {
  const { addTransaction, warehouses, meterTypes } = useInventory();
  
  const [warehouseId, setWarehouseId] = useState<string>(initialData?.warehouseId || warehouses[0]?.id || '');
  const [meterTypeId, setMeterTypeId] = useState<string>(initialData?.meterTypeId || meterTypes[0]?.id || '');
  const [transactionType, setTransactionType] = useState<TransactionType>(initialData?.transactionType || TransactionType.IN);
  const [quantity, setQuantity] = useState<number>(1);
  const [notes, setNotes] = useState<string>('');
  const [userName, setUserName] = useState<string>('Almoxarife A');

  const [feedbackMessage, setFeedbackMessage] = useState<{type: 'success' | 'error', text: string} | null>(null);
  const [isAdjustmentMode, setIsAdjustmentMode] = useState<boolean>(false);

  useEffect(() => {
    if (initialData) {
      if (initialData.warehouseId) setWarehouseId(initialData.warehouseId);
      if (initialData.meterTypeId) setMeterTypeId(initialData.meterTypeId);
      if (initialData.transactionType) {
        setTransactionType(initialData.transactionType);
        setIsAdjustmentMode(initialData.transactionType === TransactionType.ADJUSTMENT);
      }
      setQuantity(initialData.transactionType === TransactionType.ADJUSTMENT ? 0 : 1);
    } else {
        setWarehouseId(warehouses[0]?.id || '');
        setMeterTypeId(meterTypes[0]?.id || '');
        setTransactionType(TransactionType.IN);
        setQuantity(1);
        setIsAdjustmentMode(false);
        setNotes('');
        // setUserName should persist or have a default
    }
  }, [initialData, warehouses, meterTypes]);


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!warehouseId || !meterTypeId) {
      setFeedbackMessage({type: 'error', text:'Por favor, selecione almoxarifado e tipo de medidor.'});
      return;
    }
    if (transactionType !== TransactionType.ADJUSTMENT && quantity <= 0) {
       setFeedbackMessage({type: 'error', text: 'Para Entradas/Saídas, a quantidade deve ser positiva.'});
       return;
    }
    if (transactionType === TransactionType.ADJUSTMENT && quantity === 0 && !notes) {
        setFeedbackMessage({type: 'error', text: 'Para Ajustes com quantidade zero, por favor, adicione uma nota explicativa.'});
        return; 
    }

    addTransaction({ warehouseId, meterTypeId, transactionType, quantity, notes, userName });
    setFeedbackMessage({type: 'success', text: 'Transação adicionada com sucesso!'});
    
    if (!initialData || !isAdjustmentMode) { // Reset general form
        setWarehouseId(warehouses[0]?.id || '');
        setMeterTypeId(meterTypes[0]?.id || '');
        setTransactionType(TransactionType.IN);
        setQuantity(1);
        setNotes('');
        setIsAdjustmentMode(false); 
    } else { // Reset only quantity and notes for adjustment originating from current stock
        setQuantity(0);
        setNotes('');
    }

    setTimeout(() => setFeedbackMessage(null), 4000);
  };
  
  const selectedMeterType = meterTypes.find(mt => mt.id === meterTypeId);
  const selectedWarehouse = warehouses.find(wh => wh.id === warehouseId);

  const commonInputClass = "mt-1 block w-full p-3 border border-slate-300 rounded-xl shadow-sm focus:ring-2 focus:ring-blue-600 focus:border-blue-600 sm:text-base bg-slate-100 text-slate-800 placeholder-slate-600 transition-all duration-150 ease-in-out hover:shadow-md focus:shadow-md";
  const commonLabelClass = "block text-base font-bold text-slate-700 mb-2";

  return (
    <form onSubmit={handleSubmit} className="bg-white p-8 md:p-10 rounded-2xl shadow-2xl space-y-6">
      <h2 className="text-3xl md:text-4xl font-extrabold text-slate-800 mb-6 md:mb-8 text-center">
        {isAdjustmentMode ? 'Ajustar Estoque' : 'Registrar Movimentação'}
      </h2>
      
      {isAdjustmentMode && selectedMeterType && selectedWarehouse && (
        <div className="space-y-3 bg-blue-50 p-4 rounded-xl border border-blue-300 shadow-sm">
            <p className="text-base text-blue-800">
                <span className="font-bold text-blue-900">Almoxarifado:</span> {selectedWarehouse.name}
            </p>
            <p className="text-base text-blue-800">
                <span className="font-bold text-blue-900">Medidor:</span> {selectedMeterType.codE4E} - {selectedMeterType.descricao}
            </p>
            {initialData?.currentQuantity !== undefined && (
                <p className="text-base text-blue-800">
                    <span className="font-bold text-blue-900">Quantidade Atual:</span> {initialData.currentQuantity}
                </p>
            )}
        </div>
      )}

      {feedbackMessage && (
        <div 
          role="alert"
          aria-live={feedbackMessage.type === 'error' ? 'assertive' : 'polite'}
          className={`flex items-center p-4 rounded-xl text-base ${feedbackMessage.type === 'success' ? 'bg-green-100 text-green-800 border border-green-300' : 'bg-red-100 text-red-800 border border-red-300'}`}
        >
          {feedbackMessage.type === 'success' ? <SuccessIcon className="w-6 h-6 mr-3 flex-shrink-0" /> : <ErrorIcon className="w-6 h-6 mr-3 flex-shrink-0" />}
          <span>{feedbackMessage.text}</span>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-5">
        <div>
          <label htmlFor="warehouseId" className={commonLabelClass}>Almoxarifado</label>
          <select
            id="warehouseId"
            value={warehouseId}
            onChange={(e) => setWarehouseId(e.target.value)}
            className={commonInputClass}
            disabled={isAdjustmentMode && !!initialData?.warehouseId}
            aria-required="true"
          >
            {warehouses.map((wh: WarehouseInfo) => (
              <option key={wh.id} value={wh.id}>{wh.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="meterTypeId" className={commonLabelClass}>Tipo de Medidor</label>
          <select
            id="meterTypeId"
            value={meterTypeId}
            onChange={(e) => setMeterTypeId(e.target.value)}
            className={commonInputClass}
            disabled={isAdjustmentMode && !!initialData?.meterTypeId}
            aria-required="true"
          >
            {meterTypes.map((mt: MeterType) => (
              <option key={mt.id} value={mt.id}>{mt.codE4E} - {mt.descricao}</option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="transactionType" className={commonLabelClass}>Tipo de Transação</label>
          <select
            id="transactionType"
            value={transactionType}
            onChange={(e) => {
              const newType = e.target.value as TransactionType;
              setTransactionType(newType);
              const wasPredefinedAdjustment = initialData && initialData.transactionType === TransactionType.ADJUSTMENT;
              const isNowAdjustment = newType === TransactionType.ADJUSTMENT;
              
              setIsAdjustmentMode(isNowAdjustment);
              
              if (isNowAdjustment) {
                  setQuantity(wasPredefinedAdjustment && newType === initialData.transactionType ? (initialData.currentQuantity !== undefined ? 0 : 0) : 0);
              } else {
                  setQuantity(1);
              }

            }}
            className={commonInputClass}
            disabled={isAdjustmentMode && !!initialData?.transactionType}
            aria-required="true"
          >
            {Object.values(TransactionType).map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="quantity" className={commonLabelClass}>
            {transactionType === TransactionType.ADJUSTMENT 
              ? 'Valor do Ajuste (+/-)' 
              : 'Quantidade'}
          </label>
          <input
            type="number"
            id="quantity"
            value={quantity}
            onChange={(e) => setQuantity(parseInt(e.target.value, 10))}
            min={transactionType === TransactionType.ADJUSTMENT ? undefined : "1"}
            className={commonInputClass}
            aria-required="true"
            placeholder={transactionType === TransactionType.ADJUSTMENT ? "Ex: 10 ou -5" : "Ex: 1"}
          />
          {transactionType === TransactionType.ADJUSTMENT && (
              <p className="text-sm text-slate-600 mt-2">
                  Insira um valor positivo para aumentar o estoque (ex: 10) ou negativo para diminuir (ex: -5).
              </p>
          )}
        </div>
        
        <div className="md:col-span-2">
          <label htmlFor="userName" className={commonLabelClass}>Registrado por</label>
          <input
            type="text"
            id="userName"
            value={userName}
            onChange={(e) => setUserName(e.target.value)}
            className={commonInputClass}
            aria-required="true"
            placeholder="Seu nome ou identificação"
          />
        </div>

        <div className="md:col-span-2">
          <label htmlFor="notes" className={commonLabelClass}>Notas (Opcional)</label>
          <textarea
            id="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={3}
            className={commonInputClass}
            placeholder="Ex: Correção de contagem, material danificado..."
          />
        </div>
      </div>

      <button
        type="submit"
        className="w-full py-3 px-6 bg-blue-600 hover:bg-blue-700 text-white text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl focus:outline-none focus:ring-4 focus:ring-offset-2 focus:ring-blue-400 transition-all duration-200 ease-in-out transform hover:-translate-y-0.5 active:translate-y-0 active:shadow-md"
      >
        {isAdjustmentMode ? 'Registrar Ajuste' : 'Registrar Movimentação'}
      </button>
    </form>
  );
};

export default DataEntryForm;

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { APP_TITLE } from '../constants';
import { useAuth } from '../contexts/AuthContext';

const LogoutIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
    <polyline points="16 17 21 12 16 7"></polyline>
    <line x1="21" y1="12" x2="9" y2="12"></line>
  </svg>
);

const Navbar: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="bg-blue-700 text-white p-4 shadow-md print:hidden">
      <div className="container mx-auto flex justify-between items-center">
        <h1 className="text-2xl font-bold">{APP_TITLE}</h1>
        {currentUser && (
          <div className="flex items-center space-x-4">
            <span className="text-sm hidden sm:block">
              Usuário: <span className="font-semibold">{currentUser.name} ({currentUser.role})</span>
            </span>
            <button
              onClick={handleLogout}
              className="flex items-center text-sm bg-blue-600 hover:bg-blue-500 px-3 py-2 rounded-lg transition-colors duration-150"
              title="Sair do sistema"
              aria-label="Sair do sistema"
            >
              <LogoutIcon className="w-5 h-5 mr-0 sm:mr-2" />
              <span className="hidden sm:inline">Sair</span>
            </button>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;

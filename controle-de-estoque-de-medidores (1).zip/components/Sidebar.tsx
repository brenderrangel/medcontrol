import React from 'react';
import { NavLink } from 'react-router-dom';
import { HomeIcon, ListPlusIcon, ArchiveIcon, HistoryIcon, PackageSearchIcon, UsersIcon } from './icons/LucideIcons'; // Added UsersIcon to import
import { useAuth } from '../contexts/AuthContext';

const Sidebar: React.FC = () => {
  const { currentUser } = useAuth();
  const commonLinkClass = "flex items-center space-x-3 p-3 rounded-lg hover:bg-blue-600 hover:text-white transition-colors duration-200";
  const activeLinkClass = "bg-blue-700 text-white font-semibold";

  return (
    <aside className="w-64 bg-blue-800 text-blue-100 p-4 space-y-2 print:hidden">
      <NavLink to="/dashboard" className={({ isActive }) => `${commonLinkClass} ${isActive ? activeLinkClass : ''}`}>
        <HomeIcon className="w-5 h-5" />
        <span>Dashboard</span>
      </NavLink>
      <NavLink to="/data-input" className={({ isActive }) => `${commonLinkClass} ${isActive ? activeLinkClass : ''}`}>
        <ListPlusIcon className="w-5 h-5" />
        <span>Entrada de Dados</span>
      </NavLink>
      <NavLink to="/current-stock" className={({ isActive }) => `${commonLinkClass} ${isActive ? activeLinkClass : ''}`}>
        <ArchiveIcon className="w-5 h-5" />
        <span>Estoque Atual</span>
      </NavLink>
      <NavLink to="/inventory-log" className={({ isActive }) => `${commonLinkClass} ${isActive ? activeLinkClass : ''}`}>
        <HistoryIcon className="w-5 h-5" />
        <span>Histórico</span>
      </NavLink>
      <NavLink to="/meter-types" className={({ isActive }) => `${commonLinkClass} ${isActive ? activeLinkClass : ''}`}>
        <PackageSearchIcon className="w-5 h-5" />
        <span>Tipos de Medidores</span>
      </NavLink>

      {/* Conditional link for User Management - visible only to admins */}
      {currentUser && currentUser.role === 'admin' && (
        <NavLink 
          to="/user-management"
          className={({ isActive }) => `${commonLinkClass} ${isActive ? activeLinkClass : ''}`}
        >
          <UsersIcon className="w-5 h-5" />
          <span>Gerenciar Usuários</span>
        </NavLink>
      )}
    </aside>
  );
};

export default Sidebar;

import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import { ChartData } from '../../types';

interface WarehouseStockChartProps {
  data: ChartData[]; // Expects data in format { name: 'Warehouse Name', value: totalStock }
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#84A9D2', '#A5D8B8', '#FFDDAA', '#FFB093', '#C7A4FF', '#FF8A80']; // More distinct colors

interface CustomLegendProps {
  chartData: ChartData[];
  chartColors: string[];
}

const RenderCustomLegend: React.FC<CustomLegendProps> = ({ chartData, chartColors }) => {
  if (!chartData || chartData.length === 0) {
    return null;
  }

  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '10px 15px', marginTop: '0px', paddingTop: '10px' }}>
      {chartData.map((entry: ChartData, index: number) => (
        <div key={`legend-item-${index}`} style={{ display: 'flex', alignItems: 'center', fontSize: '12px', color: '#374151' /* text-gray-700 */ }}>
          <span style={{
            display: 'inline-block',
            width: '12px',
            height: '12px',
            backgroundColor: chartColors[index % chartColors.length],
            marginRight: '6px',
            borderRadius: '3px',
            border: '1px solid rgba(0,0,0,0.05)'
          }}></span>
          {entry.name}
        </div>
      ))}
    </div>
  );
};


const WarehouseStockChart: React.FC<WarehouseStockChartProps> = ({ data }) => {
   if (!data || data.length === 0) {
    return <p className="text-center text-gray-500">Dados insuficientes para exibir o gráfico de estoque por almoxarifado.</p>;
  }
  return (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis 
            dataKey="name" 
            interval={0} 
            angle={-35} 
            textAnchor="end" 
            height={80}  // Increased height for angled labels
            tick={{ fontSize: 11, fill: '#4B5563' /* text-gray-600 */}} 
        />
        <YAxis tick={{ fontSize: 11, fill: '#4B5563' }} />
        <Tooltip 
            formatter={(value: number, name: string, props: any) => [`${value} unidades`, props.payload.name]} 
            cursor={{fill: 'rgba(200,200,200,0.1)'}}
        />
        <Legend 
            content={<RenderCustomLegend chartData={data} chartColors={COLORS} />} 
            verticalAlign="bottom" 
            wrapperStyle={{ paddingTop: '20px', paddingBottom: '10px' }} // Ensure space for legend
        />
        <Bar dataKey="value">
            {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
};

export default WarehouseStockChart;

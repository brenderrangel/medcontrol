
import React, { useState, useEffect } from 'react';
import { useInventory } from '../contexts/InventoryContext';
import { MeterType } from '../types';

interface MeterTypeFormProps {
  meterToEdit?: MeterType | null;
  onSuccess: () => void;
  onCancel: () => void;
}

const MeterTypeForm: React.FC<MeterTypeFormProps> = ({ meterToEdit, onSuccess, onCancel }) => {
  const { addMeterType, updateMeterType } = useInventory();

  const initialFormState: Omit<MeterType, 'id' | 'saldoEmergencia' | 'saldoNL' | 'lteLigTemp' | 'reaproveitados'> = {
    codE4E: '',
    codSAP: '',
    tipo: '',
    descricao: '',
    corrente: '',
    fase: '',
  };

  const [formData, setFormData] = useState(initialFormState);
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  useEffect(() => {
    if (meterToEdit) {
      setFormData({
        codE4E: meterToEdit.codE4E,
        codSAP: meterToEdit.codSAP,
        tipo: meterToEdit.tipo,
        descricao: meterToEdit.descricao,
        corrente: meterToEdit.corrente,
        fase: meterToEdit.fase,
      });
      setFeedbackMessage(null); // Clear feedback when a new meter is loaded for editing
    } else {
      setFormData(initialFormState);
    }
  }, [meterToEdit]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.codE4E || !formData.codSAP || !formData.tipo || !formData.descricao || !formData.corrente || !formData.fase) {
      setFeedbackMessage({ type: 'error', message: 'Todos os campos são obrigatórios.' });
      return;
    }

    let result;
    if (meterToEdit) { // Edit mode
      result = updateMeterType({ ...meterToEdit, ...formData }); // Pass full MeterType object with id
    } else { // Add mode
      result = addMeterType(formData);
    }

    setFeedbackMessage({ type: result.success ? 'success' : 'error', message: result.message });

    if (result.success) {
      setTimeout(() => {
        setFeedbackMessage(null);
        onSuccess(); 
      }, 1500);
       if (!meterToEdit) { // Reset form only if in add mode and successful
          setFormData(initialFormState);
       }
    }
  };
  
  const commonInputClass = "mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm";
  const commonLabelClass = "block text-sm font-medium text-gray-700 mb-1";
  const formTitle = meterToEdit ? "Editar Tipo de Medidor" : "Adicionar Novo Tipo de Medidor";
  const submitButtonText = meterToEdit ? "Salvar Alterações" : "Adicionar Tipo de Medidor";

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md space-y-6 border border-blue-200">
      <h3 className="text-xl font-semibold text-gray-700 mb-4">{formTitle}</h3>
      
      {feedbackMessage && (
        <div className={`p-3 rounded-md text-sm ${feedbackMessage.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
          {feedbackMessage.message}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="codE4E" className={commonLabelClass}>Código E4E</label>
          <input type="text" id="codE4E" name="codE4E" value={formData.codE4E} onChange={handleChange} className={commonInputClass} required />
        </div>
        <div>
          <label htmlFor="codSAP" className={commonLabelClass}>Código SAP</label>
          <input type="text" id="codSAP" name="codSAP" value={formData.codSAP} onChange={handleChange} className={commonInputClass} required />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <label htmlFor="tipo" className={commonLabelClass}>Tipo</label>
          <input type="text" id="tipo" name="tipo" value={formData.tipo} onChange={handleChange} className={commonInputClass} required />
        </div>
        <div>
          <label htmlFor="corrente" className={commonLabelClass}>Corrente</label>
          <input type="text" id="corrente" name="corrente" value={formData.corrente} onChange={handleChange} className={commonInputClass} required />
        </div>
        <div>
          <label htmlFor="fase" className={commonLabelClass}>Fase</label>
          <input type="text" id="fase" name="fase" value={formData.fase} onChange={handleChange} className={commonInputClass} required />
        </div>
      </div>
      
      <div>
        <label htmlFor="descricao" className={commonLabelClass}>Descrição</label>
        <textarea id="descricao" name="descricao" value={formData.descricao} onChange={handleChange} rows={3} className={commonInputClass} required />
      </div>

      <div className="flex justify-end space-x-3">
        <button
          type="button"
          onClick={onCancel}
          className="py-2 px-4 bg-gray-200 hover:bg-gray-300 text-gray-700 font-semibold rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400 transition-colors duration-150"
        >
          Cancelar
        </button>
        <button
          type="submit"
          className="py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-150"
        >
          {submitButtonText}
        </button>
      </div>
    </form>
  );
};

export default MeterTypeForm;

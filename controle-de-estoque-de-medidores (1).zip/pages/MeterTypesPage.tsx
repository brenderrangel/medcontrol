import React, { useState } from 'react';
import { useInventory } from '../contexts/InventoryContext';
import { MeterType } from '../types';
import MeterTypeForm from '../components/AddMeterTypeForm'; // Corrected import path
import { ListPlusIcon, Edit2Icon } from '../components/icons/LucideIcons';

const MeterTypesPage: React.FC = () => {
  const { meterTypes } = useInventory();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingMeterType, setEditingMeterType] = useState<MeterType | null>(null);

  const handleAddNew = () => {
    setEditingMeterType(null);
    setIsFormOpen(true);
  };

  const handleEdit = (meterType: MeterType) => {
    setEditingMeterType(meterType);
    setIsFormOpen(true);
  };

  const handleFormSuccess = () => {
    setIsFormOpen(false);
    setEditingMeterType(null);
  };

  const handleFormCancel = () => {
    setIsFormOpen(false);
    setEditingMeterType(null);
  };

  return (
    <div className="container mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Tipos de Medidores Cadastrados</h1>
        {!isFormOpen && (
            <button
            onClick={handleAddNew}
            className="flex items-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg shadow-md transition-colors duration-150"
            >
            <ListPlusIcon className="w-5 h-5 mr-2" />
            Adicionar Novo Tipo
            </button>
        )}
      </div>

      {isFormOpen && (
        <div className="mb-6">
          <MeterTypeForm
            meterToEdit={editingMeterType}
            onSuccess={handleFormSuccess}
            onCancel={handleFormCancel}
          />
        </div>
      )}
      
      {!isFormOpen && meterTypes.length === 0 ? (
         <div className="bg-white p-6 rounded-lg shadow-md">
            <p className="text-gray-600 text-center">Nenhum tipo de medidor cadastrado.</p>
        </div>
      ) : !isFormOpen && meterTypes.length > 0 ? (
        <div className="bg-white p-6 rounded-lg shadow-md overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-blue-600">
              <tr>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Cód. E4E</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Cód. SAP</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Tipo</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Descrição</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Corrente</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Fase</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Ações</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {meterTypes.sort((a,b) => a.codE4E.localeCompare(b.codE4E)).map((mt: MeterType) => (
                <tr key={mt.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-700">{mt.codE4E}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{mt.codSAP}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{mt.tipo}</td>
                  <td className="px-4 py-3 whitespace-normal text-sm text-gray-500 max-w-xs break-words">{mt.descricao}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{mt.corrente}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{mt.fase}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                    <button
                      onClick={() => handleEdit(mt)}
                      className="text-blue-600 hover:text-blue-800 p-1 rounded hover:bg-blue-100"
                      title="Editar Tipo de Medidor"
                      aria-label="Editar Tipo de Medidor"
                    >
                      <Edit2Icon className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
    </div>
  );
};

export default MeterTypesPage;
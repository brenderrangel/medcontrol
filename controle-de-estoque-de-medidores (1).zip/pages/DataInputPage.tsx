import React from 'react';
import { useLocation } from 'react-router-dom';
import DataEntryForm from '../components/DataEntryForm';
import { TransactionType } from '../types';

interface DataInputLocationState {
  warehouseId?: string;
  meterTypeId?: string;
  currentQuantity?: number;
  transactionType?: TransactionType;
}

const DataInputPage: React.FC = () => {
  const location = useLocation();
  const initialState = location.state as DataInputLocationState | null;

  return (
    <div className="container mx-auto py-8">
      <div className="max-w-3xl mx-auto">
        <DataEntryForm initialData={initialState} />
      </div>
    </div>
  );
};

export default DataInputPage;
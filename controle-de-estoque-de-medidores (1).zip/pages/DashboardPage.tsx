
import React, { useMemo } from 'react';
import { useInventory } from '../contexts/InventoryContext';
import MeterTypeDistributionChart from '../components/charts/MeterTypeDistributionChart';
import WarehouseStockChart from '../components/charts/WarehouseStockChart';
import { ChartData, TransactionType } from '../types';
import { ArchiveIcon, ListPlusIcon, HistoryIcon } from '../components/icons/LucideIcons';
import { Link } from 'react-router-dom';

const DashboardPage: React.FC = () => {
  const { currentStock, meterTypes, warehouses, transactions } = useInventory();

  const totalStockValue = useMemo(() => {
    return currentStock.reduce((sum, item) => sum + item.quantity, 0);
  }, [currentStock]);

  const meterTypeDistributionData: ChartData[] = useMemo(() => {
    const dataMap = new Map<string, number>();
    currentStock.forEach(item => {
      const meterName = meterTypes.find(mt => mt.id === item.meterTypeId)?.codE4E || 'Desconhecido';
      dataMap.set(meterName, (dataMap.get(meterName) || 0) + item.quantity);
    });
    return Array.from(dataMap.entries())
      .map(([name, value]) => ({ name, value }))
      .filter(item => item.value > 0);
  }, [currentStock, meterTypes]);

  const warehouseStockData: ChartData[] = useMemo(() => {
    const dataMap = new Map<string, number>();
    currentStock.forEach(item => {
      const warehouseName = warehouses.find(wh => wh.id === item.warehouseId)?.name || 'Desconhecido';
      dataMap.set(warehouseName, (dataMap.get(warehouseName) || 0) + item.quantity);
    });
    return Array.from(dataMap.entries())
      .map(([name, value]) => ({ name, value }))
      .filter(item => item.value > 0);
  }, [currentStock, warehouses]);
  
  const recentTransactions = useMemo(() => {
    return [...transactions]
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 5);
  }, [transactions]);

  const SummaryCard: React.FC<{ title: string; value: string | number; icon: React.ReactNode; linkTo?: string; bgColor?: string }> = ({ title, value, icon, linkTo, bgColor = 'bg-blue-500' }) => (
    <Link to={linkTo || '#'} className={`p-6 rounded-xl shadow-lg flex items-center space-x-4 text-white hover:opacity-90 transition-opacity ${bgColor}`}>
      <div className="p-3 bg-white bg-opacity-20 rounded-full">{icon}</div>
      <div>
        <p className="text-sm font-medium uppercase tracking-wider">{title}</p>
        <p className="text-3xl font-bold">{value}</p>
      </div>
    </Link>
  );

  return (
    <div className="container mx-auto space-y-8">
      <h1 className="text-3xl font-bold text-gray-800">Dashboard de Estoque</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <SummaryCard title="Total em Estoque" value={totalStockValue} icon={<ArchiveIcon className="w-8 h-8 text-white"/>} linkTo="/current-stock" bgColor="bg-blue-600" />
        <SummaryCard title="Tipos de Medidores" value={meterTypes.length} icon={<ListPlusIcon className="w-8 h-8 text-white"/>} linkTo="/meter-types" bgColor="bg-green-500" />
        <SummaryCard title="Total de Transações" value={transactions.length} icon={<HistoryIcon className="w-8 h-8 text-white"/>} linkTo="/inventory-log" bgColor="bg-indigo-500" />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <h2 className="text-xl font-semibold text-gray-700 mb-4">Distribuição por Tipo de Medidor</h2>
          <MeterTypeDistributionChart data={meterTypeDistributionData} />
        </div>
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <h2 className="text-xl font-semibold text-gray-700 mb-4">Estoque por Almoxarifado</h2>
          <WarehouseStockChart data={warehouseStockData} />
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-lg">
        <h2 className="text-xl font-semibold text-gray-700 mb-4">Últimas Movimentações</h2>
        {recentTransactions.length === 0 ? (
          <p className="text-gray-500">Nenhuma movimentação recente.</p>
        ) : (
          <ul className="divide-y divide-gray-200">
            {recentTransactions.map(t => (
              <li key={t.id} className="py-3 flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-gray-800">
                    {meterTypes.find(mt => mt.id === t.meterTypeId)?.codE4E} - {warehouses.find(w => w.id === t.warehouseId)?.name}
                  </p>
                  <p className="text-xs text-gray-500">{new Date(t.timestamp).toLocaleString()} por {t.userName || 'N/A'}</p>
                </div>
                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                  t.transactionType === TransactionType.IN ? 'bg-green-100 text-green-700' : 
                  t.transactionType === TransactionType.OUT ? 'bg-red-100 text-red-700' : 
                  'bg-yellow-100 text-yellow-700'
                }`}>
                  {t.transactionType}: {t.quantity}
                </span>
              </li>
            ))}
          </ul>
        )}
         {transactions.length > 5 && (
            <div className="mt-4 text-right">
                <Link to="/inventory-log" className="text-sm text-blue-600 hover:text-blue-800 font-medium">
                    Ver todas as movimentações &rarr;
                </Link>
            </div>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;

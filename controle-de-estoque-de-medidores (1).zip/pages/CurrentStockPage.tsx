
import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useInventory } from '../contexts/InventoryContext';
import { CurrentStock, WarehouseInfo, MeterType, TransactionType } from '../types';
import { Edit2Icon } from '../components/icons/LucideIcons';

// Declare jsPDF type globally
declare global {
  interface jsPDF {
    setFontSize(size: number): this;
    text(text: string | string[], x: number, y: number, options?: any, transform?: any): this;
    save(filename: string): void;
    setFont(fontName: string, fontStyle: string): this; // Used for setFontStyle
    setFontStyle?(style: string): this; // Legacy, maps to setFont
    addPage(): this; // Added method
    internal: { // Added property
      pageSize: {
        getWidth(): number;
        getHeight(): number;
      };
      getNumberOfPages(): number;
    };
    // Add other jsPDF methods used directly or by plugins if necessary
  }
}

interface jsPDFWithAutoTable extends jsPDF {
  autoTable: (options: any) => jsPDFWithAutoTable;
  lastAutoTable?: { finalY?: number };
}

const TOP_MARGIN = 55; // Increased top margin for the new header
const BOTTOM_MARGIN = 25; // Bottom margin for footer

const CurrentStockPage: React.FC = () => {
  const { currentStock, warehouses, meterTypes } = useInventory();
  const navigate = useNavigate();
  const [filterWarehouse, setFilterWarehouse] = useState<string>('');
  const [filterMeterType, setFilterMeterType] = useState<string>('');
  const [filterQuantityCondition, setFilterQuantityCondition] = useState<string>('');

  const filteredStock = useMemo(() => {
    return currentStock.filter(item => 
      (filterWarehouse === '' || item.warehouseId === filterWarehouse) &&
      (filterMeterType === '' || item.meterTypeId === filterMeterType) &&
      (filterQuantityCondition === '' ||
        (filterQuantityCondition === '>' && item.quantity > 0) ||
        (filterQuantityCondition === '<' && item.quantity < 0) ||
        (filterQuantityCondition === '=' && item.quantity === 0)
      )
    );
  }, [currentStock, filterWarehouse, filterMeterType, filterQuantityCondition]);

  const getMeterCodE4E = (meterId: string) => {
    return meterTypes.find(m => m.id === meterId)?.codE4E || 'N/A';
  }
  
  const getCurrentFilterText = () => {
    let filters = [];
    if (filterWarehouse) {
        filters.push(`Almoxarifado: ${warehouses.find(w => w.id === filterWarehouse)?.name || filterWarehouse}`);
    }
    if (filterMeterType) {
        const mt = meterTypes.find(m => m.id === filterMeterType);
        filters.push(`Medidor: ${mt?.codE4E || filterMeterType} (${mt?.descricao || ''})`);
    }
    if (filterQuantityCondition) {
        const condMap: {[key: string]: string} = { '>': 'Positiva', '<': 'Negativa', '=': 'Zero'};
        filters.push(`Quantidade: ${condMap[filterQuantityCondition]}`);
    }
    return filters.length > 0 ? `Filtros Ativos: ${filters.join('; ')}` : 'Filtros Ativos: Nenhum';
  };

  const getWarehouseFilterTextForHeader = (warehouseId: string, warehousesList: WarehouseInfo[]): string => {
    if (!warehouseId) {
        return "Todos Almoxarifados";
    }
    const warehouse = warehousesList.find(w => w.id === warehouseId);
    return warehouse ? warehouse.name : "Desconhecido";
  };

  const addHeaderToPage = (doc: jsPDFWithAutoTable, reportTitleStr: string, generatedDateStr: string, whFilterText: string, currentFiltersStr: string) => {
    const pageWidth = doc.internal.pageSize.getWidth();
    
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("LOGO EMPRESA", 14, 15);
    doc.setFont("helvetica", "normal");

    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");
    doc.text(reportTitleStr, pageWidth / 2, 18, { align: 'center' });
    doc.setFont("helvetica", "normal");

    let textY = 15;
    doc.setFontSize(9);
    doc.text(`Gerado em: ${generatedDateStr}`, pageWidth - 14, textY, { align: 'right' });
    textY += 5;
    doc.text("Responsável: Almoxarife Principal", pageWidth - 14, textY, { align: 'right' });
    textY += 5;
    doc.text(`Unidade Almoxarifado: ${whFilterText}`, pageWidth - 14, textY, { align: 'right' });
    
    textY += 7; 
    doc.setFontSize(8);
    doc.text(currentFiltersStr, 14, textY, {maxWidth: pageWidth - 28});
  };

  const addFooterToPage = (doc: jsPDFWithAutoTable, pageNum: number, totalPages: number) => {
    const pageHeight = doc.internal.pageSize.getHeight();
    const pageWidth = doc.internal.pageSize.getWidth();
    doc.setFontSize(8);
    doc.text("Confidencial", 14, pageHeight - 10);
    doc.text("Sistema de Controle de Estoque de Medidores", pageWidth / 2, pageHeight - 10, { align: 'center' });
    doc.text(`Página ${pageNum} de ${totalPages}`, pageWidth - 14, pageHeight - 10, { align: 'right' });
  };


  const handleExportPDFCompleto = () => {
    if (filteredStock.length === 0) {
      alert("Nenhum dado para exportar com os filtros selecionados.");
      return;
    }
    
    const JsPDFConstructor = (window as any)?.jspdf?.jsPDF; 
    if (!JsPDFConstructor) {
        alert("jsPDF não está carregado.");
        console.error("window.jspdf.jsPDF is not available.");
        return;
    }
    const doc = new JsPDFConstructor({ orientation: 'p', unit: 'mm', format: 'a4' }) as jsPDFWithAutoTable;
    
    const generatedDateTime = new Date().toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    const reportTitle = "Relatório de Estoque Completo";
    const warehouseHeaderText = getWarehouseFilterTextForHeader(filterWarehouse, warehouses);
    const filtersAppliedText = getCurrentFilterText();

    const tableColumn = ["Almoxarifado", "Cód. E4E Medidor", "Descrição Medidor", "Quantidade"];
    const tableRows = filteredStock.map(item => [
      item.warehouseName,
      getMeterCodE4E(item.meterTypeId),
      item.meterTypeDesc,
      item.quantity
    ]);

    doc.autoTable({ 
      head: [tableColumn],
      body: tableRows,
      startY: TOP_MARGIN,
      theme: 'striped',
      headStyles: { fillColor: [22, 100, 133], textColor: 255, fontStyle: 'bold' }, // Darker blue
      styles: { fontSize: 8, cellPadding: 1.5 },
      columnStyles: {
        0: { cellWidth: 35 }, // Almoxarifado
        1: { cellWidth: 25 }, // Cód. E4E
        2: { cellWidth: 'auto' }, // Descrição
        3: { cellWidth: 20, halign: 'right' }, // Quantidade
      },
      margin: { top: TOP_MARGIN, bottom: BOTTOM_MARGIN, left: 14, right: 14 },
      didDrawPage: (data) => {
        addHeaderToPage(doc, reportTitle, generatedDateTime, warehouseHeaderText, filtersAppliedText);
        addFooterToPage(doc, data.pageNumber, doc.internal.getNumberOfPages());
      }
    });
    
    const fileNameDate = new Date().toISOString().slice(0, 10);
    doc.save(`Relatorio_Estoque_Completo_${fileNameDate}.pdf`);
  };

  const handleExportPDFResumido = () => {
    if (filteredStock.length === 0) { 
      alert("Nenhum dado para exportar com os filtros selecionados.");
      return;
    }

    const JsPDFConstructor = (window as any)?.jspdf?.jsPDF;
    if (!JsPDFConstructor) {
        alert("jsPDF não está carregado.");
        console.error("window.jspdf.jsPDF is not available.");
        return;
    }
    const doc = new JsPDFConstructor({ orientation: 'p', unit: 'mm', format: 'a4' }) as jsPDFWithAutoTable;
    
    const generatedDateTime = new Date().toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    const reportTitle = "Relatório de Estoque Resumido";
    const warehouseHeaderText = getWarehouseFilterTextForHeader(filterWarehouse, warehouses);
    const filtersAppliedText = getCurrentFilterText();

    let currentY = TOP_MARGIN;

    // --- Resumo Geral ---
    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.text("Resumo Geral:", 14, currentY);
    currentY += 6;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    const totalOverallQuantity = filteredStock.reduce((sum, item) => sum + item.quantity, 0);
    doc.text(`Total de Itens em Estoque (todas unidades): ${totalOverallQuantity}`, 14, currentY);
    currentY += 10;

    // --- Estoque por Almoxarifado ---
    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.text("Estoque por Almoxarifado:", 14, currentY);
    currentY += 6;
    
    const stockByWarehouse: {[key: string]: { name: string, quantity: number }} = {};
    filteredStock.forEach(item => {
        if (!stockByWarehouse[item.warehouseId]) {
            stockByWarehouse[item.warehouseId] = { name: item.warehouseName, quantity: 0 };
        }
        stockByWarehouse[item.warehouseId].quantity += item.quantity;
    });

    const warehouseTableColumns = ["Almoxarifado", "Quantidade Total"];
    const warehouseTableRows = Object.values(stockByWarehouse)
                                .sort((a,b) => a.name.localeCompare(b.name))
                                .map(wh => [wh.name, wh.quantity]);
    const totalWarehouseQty = warehouseTableRows.reduce((sum, row) => sum + (row[1] as number), 0);
    warehouseTableRows.push(["TOTAL GERAL", totalWarehouseQty]);

    doc.autoTable({ 
      head: [warehouseTableColumns],
      body: warehouseTableRows,
      startY: currentY,
      theme: 'grid',
      headStyles: { fillColor: [40, 100, 180], textColor: 255, fontStyle: 'bold' },
      styles: { fontSize: 9, cellPadding: 1.5 },
      columnStyles: { 1: { halign: 'right' } },
      didParseCell: (data: any) => {
         if (data.section === 'body' && data.row.raw && data.row.raw[0] === "TOTAL GERAL") {
            data.cell.styles.fontStyle = 'bold';
            data.cell.styles.fillColor = '#f0f0f0'; // Light gray background for total
         }
      },
      margin: { top: TOP_MARGIN, bottom: BOTTOM_MARGIN, left: 14, right: 14 },
      didDrawPage: (data) => {
        addHeaderToPage(doc, reportTitle, generatedDateTime, warehouseHeaderText, filtersAppliedText);
        addFooterToPage(doc, data.pageNumber, doc.internal.getNumberOfPages());
      }
    });
    
    currentY = doc.lastAutoTable && doc.lastAutoTable.finalY ? doc.lastAutoTable.finalY + 10 : currentY + 50;

    // Check for page overflow before drawing next section title
    const pageHeight = doc.internal.pageSize.getHeight();
    if (currentY > pageHeight - BOTTOM_MARGIN - 30) { // Check if enough space for title + some table rows
        doc.addPage();
        currentY = TOP_MARGIN; 
    }
    
    // --- Estoque por Tipo de Medidor ---
    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.text("Estoque por Tipo de Medidor:", 14, currentY);
    currentY += 6;

    const stockByMeterType: { [key: string]: { codE4E: string, descricao: string, quantity: number } } = {};
    filteredStock.forEach(item => {
        const meter = meterTypes.find(m => m.id === item.meterTypeId);
        if (meter) {
            if (!stockByMeterType[item.meterTypeId]) {
                stockByMeterType[item.meterTypeId] = { 
                    codE4E: meter.codE4E, 
                    descricao: meter.descricao, 
                    quantity: 0 
                };
            }
            stockByMeterType[item.meterTypeId].quantity += item.quantity;
        }
    });
    const meterTypeTableColumns = ["Cód. E4E", "Descrição Medidor", "Quantidade Total"];
    const meterTypeTableRows = Object.values(stockByMeterType)
        .filter(mt => mt.quantity !== 0) // Only show meters with actual stock
        .sort((a,b) => a.codE4E.localeCompare(b.codE4E))
        .map(mt => [mt.codE4E, mt.descricao, mt.quantity]);
    const totalMeterTypeQty = meterTypeTableRows.reduce((sum, row) => sum + (row[2] as number), 0);
    meterTypeTableRows.push(["TOTAL GERAL", "", totalMeterTypeQty]);

    doc.autoTable({
      head: [meterTypeTableColumns],
      body: meterTypeTableRows,
      startY: currentY,
      theme: 'grid',
      headStyles: { fillColor: [40, 100, 180], textColor: 255, fontStyle: 'bold' },
      styles: { fontSize: 9, cellPadding: 1.5 },
      columnStyles: { 
        0: {cellWidth: 25}, // Cod E4E
        1: {cellWidth: 'auto'}, // Descricao
        2: {cellWidth: 30, halign: 'right'} // Quantidade
      },
      didParseCell: (data: any) => {
         if (data.section === 'body' && data.row.raw && data.row.raw[0] === "TOTAL GERAL") {
            data.cell.styles.fontStyle = 'bold';
            data.cell.styles.fillColor = '#f0f0f0'; // Light gray background for total
         }
      },
      margin: { top: TOP_MARGIN, bottom: BOTTOM_MARGIN, left: 14, right: 14 },
      didDrawPage: (data) => {
        addHeaderToPage(doc, reportTitle, generatedDateTime, warehouseHeaderText, filtersAppliedText);
        addFooterToPage(doc, data.pageNumber, doc.internal.getNumberOfPages());
      }
    });
    
    const fileNameDate = new Date().toISOString().slice(0, 10);
    doc.save(`Relatorio_Estoque_Resumido_${fileNameDate}.pdf`);
  };


  const handleExportCSV = () => {
    if (filteredStock.length === 0) {
      alert("Nenhum dado para exportar.");
      return;
    }

    const csvHeaders = ["Almoxarifado", "Cód. E4E Medidor", "Descrição Medidor", "Quantidade"];
    const csvRows = filteredStock.map(item => [
      item.warehouseName,
      getMeterCodE4E(item.meterTypeId),
      item.meterTypeDesc.replace(/"/g, '""'), 
      item.quantity
    ]);

    let csvContent = csvHeaders.join(",") + "\n";
    csvRows.forEach(rowArray => {
      const row = rowArray.map(field => typeof field === 'string' ? `"${field}"` : field).join(",");
      csvContent += row + "\n";
    });

    const blob = new Blob([`\uFEFF${csvContent}`], { type: 'text/csv;charset=utf-8;' }); // Added BOM for Excel
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      const today = new Date().toISOString().slice(0, 10);
      link.setAttribute("href", url);
      link.setAttribute("download", `estoque_atual_${today}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleAdjustStock = (item: CurrentStock) => {
    navigate('/data-input', { 
      state: { 
        warehouseId: item.warehouseId, 
        meterTypeId: item.meterTypeId,
        currentQuantity: item.quantity, 
        transactionType: TransactionType.ADJUSTMENT
      }
    });
  };

  const commonSelectClass = "mt-1 block w-full sm:w-48 md:w-56 p-2.5 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm bg-gray-50 hover:bg-gray-100 transition-colors text-slate-800";
  const commonButtonClass = "font-semibold py-2.5 px-4 rounded-lg shadow-md hover:shadow-lg transition-all duration-150 text-sm flex items-center justify-center gap-2";

  return (
    <div className="container mx-auto">
      <h1 className="text-3xl font-bold text-slate-800 mb-6 text-center md:text-left">Estoque Atual</h1>
      
      <div className="bg-white p-6 rounded-xl shadow-lg mb-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          
          {/* Filter Group */}
          <div className="flex flex-col sm:flex-row flex-wrap items-end gap-x-4 gap-y-3 w-full md:w-auto">
            <div>
              <label htmlFor="filterWarehouse" className="block text-sm font-medium text-gray-700 mb-1">Filtrar por Almoxarifado:</label>
              <select 
                id="filterWarehouse"
                value={filterWarehouse} 
                onChange={(e) => setFilterWarehouse(e.target.value)}
                className={commonSelectClass}
              >
                <option value="">Todos Almoxarifados</option>
                {warehouses.map((wh: WarehouseInfo) => (
                  <option key={wh.id} value={wh.id}>{wh.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="filterMeterType" className="block text-sm font-medium text-gray-700 mb-1">Filtrar por Medidor:</label>
              <select 
                id="filterMeterType"
                value={filterMeterType} 
                onChange={(e) => setFilterMeterType(e.target.value)}
                className={commonSelectClass}
              >
                <option value="">Todos Medidores</option>
                {meterTypes.map((mt: MeterType) => (
                  <option key={mt.id} value={mt.id}>{mt.codE4E} - {mt.descricao}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="filterQuantityCondition" className="block text-sm font-medium text-gray-700 mb-1">Filtrar por Quantidade:</label>
              <select 
                id="filterQuantityCondition"
                value={filterQuantityCondition} 
                onChange={(e) => setFilterQuantityCondition(e.target.value)}
                className={commonSelectClass}
              >
                <option value="">Todas Quantidades</option>
                <option value=">">Positiva</option>
                <option value="<">Negativa</option>
                <option value="=">Zero</option>
              </select>
            </div>
          </div>

          {/* Export Buttons Group */}
          <div className="flex flex-shrink-0 gap-3 mt-4 md:mt-0 w-full md:w-auto">
            <button
                onClick={handleExportCSV}
                className={`${commonButtonClass} bg-green-600 hover:bg-green-700 text-white w-full md:w-auto`}
                aria-label="Exportar para CSV"
            >
                CSV
            </button>
            <button
                onClick={handleExportPDFCompleto}
                className={`${commonButtonClass} bg-red-600 hover:bg-red-700 text-white w-full md:w-auto`}
                aria-label="Exportar para PDF Completo"
            >
                PDF Completo
            </button>
            <button
                onClick={handleExportPDFResumido}
                className={`${commonButtonClass} bg-orange-500 hover:bg-orange-600 text-white w-full md:w-auto`}
                aria-label="Exportar para PDF Resumido"
            >
                PDF Resumido
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        {filteredStock.length === 0 ? (
          <p className="text-gray-600 text-center py-10">Nenhum item em estoque para os filtros selecionados ou o estoque está vazio.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-blue-600">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">
                    Almoxarifado
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">
                    Cód. E4E Medidor
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">
                    Descrição Medidor
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">
                    Quantidade
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredStock.sort((a,b) => a.warehouseName.localeCompare(b.warehouseName) || getMeterCodE4E(a.meterTypeId).localeCompare(getMeterCodE4E(b.meterTypeId)) ).map((item: CurrentStock, index: number) => (
                  <tr key={`${item.meterTypeId}-${item.warehouseId}-${index}`} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.warehouseName}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{getMeterCodE4E(item.meterTypeId)}</td>
                    <td className="px-6 py-4 whitespace-normal max-w-xs md:max-w-md text-sm text-gray-500">{item.meterTypeDesc}</td>
                    <td className={`px-6 py-4 whitespace-nowrap text-sm font-semibold ${item.quantity > 0 ? 'text-green-600' : item.quantity < 0 ? 'text-red-600' : 'text-gray-700'}`}>
                      {item.quantity}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <button
                        onClick={() => handleAdjustStock(item)}
                        className="text-blue-600 hover:text-blue-800 p-1.5 rounded-md hover:bg-blue-100 transition-colors"
                        title="Ajustar Estoque"
                        aria-label="Ajustar Estoque"
                      >
                        <Edit2Icon size={18} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default CurrentStockPage;

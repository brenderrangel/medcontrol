import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useInventory } from '../contexts/InventoryContext';
import { User, WarehouseInfo } from '../types';
import UserForm from '../components/UserForm';
import { UserPlusIcon, Edit2Icon, UserXIcon } from '../components/icons/LucideIcons';

const UserManagementPage: React.FC = () => {
  const { users, deleteUser, currentUser } = useAuth();
  const { warehouses } = useInventory();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const handleAddNew = () => {
    setEditingUser(null);
    setIsFormOpen(true);
    setFeedbackMessage(null);
  };

  const handleEdit = (user: User) => {
    setEditingUser(user);
    setIsFormOpen(true);
    setFeedbackMessage(null);
  };

  const handleDelete = (userId: string) => {
    if (window.confirm('Tem certeza que deseja excluir este usuário? Esta ação não pode ser desfeita.')) {
      const result = deleteUser(userId);
      setFeedbackMessage({ type: result.success ? 'success' : 'error', message: result.message });
      if (result.success) {
        // Optionally clear feedback after a delay
        setTimeout(() => setFeedbackMessage(null), 3000);
      }
    }
  };

  const handleFormSuccess = () => {
    setIsFormOpen(false);
    setEditingUser(null);
    // Feedback message will be set by UserForm, or you can set a generic one here
    // setFeedbackMessage({ type: 'success', message: editingUser ? 'Usuário atualizado com sucesso!' : 'Usuário adicionado com sucesso!' });
    // setTimeout(() => setFeedbackMessage(null), 3000);
  };

  const handleFormCancel = () => {
    setIsFormOpen(false);
    setEditingUser(null);
    setFeedbackMessage(null);
  };

  const getWarehouseNames = (warehouseIds: string[]): string => {
    if (!warehouseIds || warehouseIds.length === 0) return 'N/A';
    return warehouseIds.map(id => warehouses.find((wh: WarehouseInfo) => wh.id === id)?.name || id).join(', ');
  };

  return (
    <div className="container mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Gerenciar Usuários</h1>
        {!isFormOpen && (
          <button
            onClick={handleAddNew}
            className="flex items-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 px-5 rounded-lg shadow-md hover:shadow-lg transition-all duration-150"
            aria-label="Adicionar Novo Usuário"
          >
            <UserPlusIcon className="w-5 h-5 mr-2" />
            Adicionar Novo Usuário
          </button>
        )}
      </div>

      {feedbackMessage && (
        <div className={`mb-4 p-3 rounded-md text-sm ${feedbackMessage.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`} role="alert">
          {feedbackMessage.message}
        </div>
      )}

      {isFormOpen && (
        <div className="mb-8">
          <UserForm
            userToEdit={editingUser}
            onSuccess={handleFormSuccess}
            onCancel={handleFormCancel}
          />
        </div>
      )}

      {!isFormOpen && users.length === 0 ? (
        <div className="bg-white p-6 rounded-lg shadow-md">
          <p className="text-gray-600 text-center py-8">Nenhum usuário cadastrado.</p>
        </div>
      ) : !isFormOpen && users.length > 0 ? (
        <div className="bg-white p-6 rounded-lg shadow-md overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-blue-700">
              <tr>
                <th scope="col" className="px-5 py-3.5 text-left text-xs font-semibold text-white uppercase tracking-wider">Nome</th>
                <th scope="col" className="px-5 py-3.5 text-left text-xs font-semibold text-white uppercase tracking-wider">Email</th>
                <th scope="col" className="px-5 py-3.5 text-left text-xs font-semibold text-white uppercase tracking-wider">Perfil</th>
                <th scope="col" className="px-5 py-3.5 text-left text-xs font-semibold text-white uppercase tracking-wider">Almoxarifados</th>
                <th scope="col" className="px-5 py-3.5 text-left text-xs font-semibold text-white uppercase tracking-wider">Ações</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {users.sort((a,b) => a.name.localeCompare(b.name)).map((user: User) => (
                <tr key={user.id} className="hover:bg-gray-50 transition-colors duration-150">
                  <td className="px-5 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{user.name}</td>
                  <td className="px-5 py-4 whitespace-nowrap text-sm text-gray-600">{user.email}</td>
                  <td className="px-5 py-4 whitespace-nowrap text-sm text-gray-600">
                    <span className={`px-2.5 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      user.role === 'admin' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
                    }`}>
                      {user.role === 'admin' ? 'Admin' : 'Usuário'}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-sm text-gray-600 max-w-xs break-words">
                    {user.role === 'admin' ? 'Todos (Admin)' : getWarehouseNames(user.assignedWarehouseIds)}
                  </td>
                  <td className="px-5 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button
                      onClick={() => handleEdit(user)}
                      className="text-blue-600 hover:text-blue-800 p-1.5 rounded-md hover:bg-blue-100 transition-colors"
                      title="Editar Usuário"
                      aria-label={`Editar usuário ${user.name}`}
                    >
                      <Edit2Icon size={18} />
                    </button>
                    {currentUser?.id !== user.id && ( // Prevent self-delete button from showing
                         <button
                            onClick={() => handleDelete(user.id)}
                            className="text-red-500 hover:text-red-700 p-1.5 rounded-md hover:bg-red-100 transition-colors"
                            title="Excluir Usuário"
                            aria-label={`Excluir usuário ${user.name}`}
                        >
                            <UserXIcon size={18} />
                        </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
    </div>
  );
};

export default UserManagementPage;